namespace Assets.scripts.grammar.runtime
{
    public class Token: Node
    {
        public string lexeme;
        public int position;

        public Terminal type;
    }
}