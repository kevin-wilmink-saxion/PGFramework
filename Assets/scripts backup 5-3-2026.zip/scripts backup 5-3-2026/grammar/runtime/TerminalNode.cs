namespace Assets.scripts.grammar.runtime
{
    public class TerminalNode: Node
    {
        public Token token;
    }
}