using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Assets.scripts.grammar.runtime
{
    public class Node
    {
        public List<Node> children = new List<Node>();
        public Node parent;

        public List<AttributeDefinition> values = new List<AttributeDefinition>();
        public Symbol symbol;



        public String TreeToString(int level = 0)
        {
            Node node = this;
            String result = "";

            //add tabs
            for (int i = 0; i < level; i++)
            {
                result += "\t";
            }

            result += node.symbol.symbolName;

            foreach (Node child in node.children)
            {
                result += "\n" + child.TreeToString(level + 1);
            }

            return result;
        }
    }
}