namespace Assets.scripts.grammar.runtime
{
    public class NonTerminalNode: Node
    {
        
    }
}