using System;
using System.Collections.Generic;
using Assets.scripts.grammar;
using Assets.scripts.grammar.runtime;
using UnityEngine;
using UnityEngine.Events;
using Random = UnityEngine.Random;

public class GrammarGenerator : MonoBehaviour
{
    //public GrammarAsset grammar;
    public List<Node> nodes = new List<Node>();
    
    public UnityEvent<Node> onGenerateTree = new UnityEvent<Node>(); 
    
    
    public void StartNewGeneration(GrammarAsset grammarAsset)
    {
        Node grammarTree = ProcessSymbol(grammarAsset.root, null);
        onGenerateTree.Invoke(grammarTree);
    }




    




    private Node ProcessSymbol(Symbol symbol, NonTerminalNode parentNode)
    {
        if (symbol == null)
        {
            //Debug.Log("DONE!");
            return null;
        }



        Node nwNode;
        if (symbol is Terminal)
        {
            nwNode = new TerminalNode();
        }
        else if (symbol is NonTerminal)
        {
            nwNode = new NonTerminalNode();
        }
        else
        {
            Debug.LogError("symbol should be terminal or non-terminal");
            return null;
        }


        nwNode.symbol = symbol;

        if (parentNode != null){
            nwNode.parent = parentNode;
            parentNode.children.Add(nwNode);
        }




        if (symbol is NonTerminal)
        {
            NonTerminal nonTerminal = (NonTerminal) symbol;
            
            Production production = getProduction(nonTerminal);
        
            //check: if there is a valid production
            if (production == null)
            {
                Debug.LogWarning("Could not find a production for the Non-Terminal: " + nonTerminal.name);
                return null;
            }

            //check: if there is the production has a valid rhs
            if (production.rhs == null)
            {
                Debug.LogWarning("A production in " + nonTerminal.name + " has a production with a null rhs");
                return null;
            }
        
        
            //do the production
            foreach (Symbol rhsSymbol in production.rhs)
            {
                Node childNode = ProcessSymbol(rhsSymbol, nwNode as NonTerminalNode);
            }
        }
        
        return nwNode;
    }




    private Production getProduction(NonTerminal nonTerminal)
    {
        List<Production> options = new List<Production>();

        options = nonTerminal.productions;
        
        if (options.Count <= 0)
        {
            return null;
        }
        
        
        //for now, return a random one
        return options[Random.Range(0, options.Count)];
    }
    
}
