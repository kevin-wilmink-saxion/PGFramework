using System.Collections.Generic;
using UnityEngine;

namespace Assets.scripts.grammar
{
    [System.Serializable]
    public class Symbol: ScriptableObject
    {
        public string symbolName;
        public List<SemanticRule> rules = new List<SemanticRule>();
    }
}