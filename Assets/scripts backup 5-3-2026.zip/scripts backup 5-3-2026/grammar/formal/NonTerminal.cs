using System.Collections.Generic;
using UnityEngine;

namespace Assets.scripts.grammar
{
    [CreateAssetMenu(fileName = "newNonTerminal", menuName = "Grammar/New Non Terminal")]
    public class NonTerminal: Symbol
    {
        public List<Production> productions = new List<Production>();
    }
}