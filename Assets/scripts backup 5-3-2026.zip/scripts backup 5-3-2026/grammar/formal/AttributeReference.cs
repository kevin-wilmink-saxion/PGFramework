namespace Assets.scripts.grammar
{
    [System.Serializable]
    public class AttributeReference
    {
        
    }
}