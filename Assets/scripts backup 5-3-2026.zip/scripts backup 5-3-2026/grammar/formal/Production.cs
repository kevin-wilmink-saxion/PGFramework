using System.Collections.Generic;


namespace Assets.scripts.grammar
{
    /// <summary>
    /// a single production that belongs to an non-terminal
    ///     (TODO: remove this class and store rhs directly on an NonTerminal?)
    /// </summary>
    
    [System.Serializable]
    public class Production
    {
        //public NonTerminal lhs; (this is stored at an NonTerminal, so that nt already acts as the lhs)
        public List<Symbol> rhs = new List<Symbol>();
    }
}