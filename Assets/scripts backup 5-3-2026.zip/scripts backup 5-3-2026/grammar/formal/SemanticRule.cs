using System.Collections.Generic;

namespace Assets.scripts.grammar
{
    [System.Serializable]
    public class SemanticRule
    {
        public AttributeReference attributeTarget;
        public List<AttributeReference> source = new List<AttributeReference>();


        public int nodeIndex; //0= lhs, 1-N= rhs (not needed?)
    }
}