using UnityEngine;

[System.Serializable]
public class AttributeDefinition
{
    public enum AttributeKind
    {
        Synthesized,
        Inherited
    }


    public string name;
    //todo: store value type? (public Type valueType)?
    
    public AttributeKind kind;
    
}
